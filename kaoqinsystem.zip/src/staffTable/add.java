package staffTable;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import data.staffInfo;
import data.staffInfoInterface;


public class add {
	public add(){
	}
	public void addFunction(){
	final JFrame f = new JFrame("增加员工信息");
		f.setSize(800, 300);
		f.setLocation(200, 200);
		f.setLayout(new BorderLayout());
		//加载model里面的窗体
		final model htm = new model();
		final JTable t = new JTable(htm);
		JPanel p = new JPanel();
		
		JLabel lsno = new JLabel("员工编号");
		final JTextField tfsno = new JTextField("");
		JLabel lsname = new JLabel("姓名");
		final JTextField tfsname = new JTextField("");
		JLabel lsage = new JLabel("年龄");
		final JTextField tfsage = new JTextField("");
		JLabel lspos = new JLabel("职位");
		final JTextField tfspos = new JTextField("");
		JLabel lssex = new JLabel("性别");
		final JTextField tfssex = new JTextField("");
		JButton bAdd = new JButton("增加");
		
		tfsno.setPreferredSize(new Dimension(60, 30));
		tfsname.setPreferredSize(new Dimension(50, 30));
		tfsage.setPreferredSize(new Dimension(40, 30));
		tfspos.setPreferredSize(new Dimension(80, 30));
		tfssex.setPreferredSize(new Dimension(40, 30));
		
		p.add(lsno);
		p.add(tfsno);
		p.add(lsname);
		p.add(tfsname);
		p.add(lsage);
		p.add(tfsage);
		p.add(lspos);
		p.add(tfspos);
		p.add(lssex);
		p.add(tfssex);
		p.add(bAdd);
		JButton a5 = new JButton("返回");
		p.add(a5);
		
		a5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		bAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//将输入的值传过去
				String name = tfsno.getText();
				String name1 = tfsname.getText();
				String name2 = tfsage.getText();
				String name3 = tfspos.getText();
				String name4 = tfssex.getText();
				if (name.length() != 0 && name1.length() != 0 && name2.length() != 0 && name3.length() != 0 && name4.length() != 0) {
					staffInfoInterface dao = new staffInfoInterface();
					staffInfo h = new staffInfo();
					h.sno = tfsno.getText();
					h.sname = tfsname.getText();
					h.sage = Integer.parseInt(tfsage.getText());
					h.spos = tfspos.getText();
					h.ssex = tfssex.getText();
					dao.add(h);
					htm.staffs = dao.list();
					t.updateUI();
				} else {
					JOptionPane.showMessageDialog(f, "输入错误！");
					tfsno.grabFocus();
				}
			}
		});
		
		JScrollPane sp = new JScrollPane(t);
		f.add(p, "North");
		f.add(sp, "Center");
		f.setDefaultCloseOperation(3);
		f.setVisible(true);
	}
}
