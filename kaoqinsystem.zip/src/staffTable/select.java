package staffTable;

import data.staffInfo;
import data.staffInfoInterface;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class select {
	public select(){
	}
	
	public void selectFunction(){
		final JFrame f = new JFrame("查找界面");
		f.setSize(400, 300);
		f.setLocation(200, 200);
		f.setLayout(new BorderLayout());
		final model htm = new model();
		final JTable t = new JTable(htm);
		t.setSelectionMode(0);
		t.getSelectionModel().setSelectionInterval(0, 0);
		JPanel p = new JPanel();
		JLabel lsno = new JLabel("编号");
		final JTextField tfsno = new JTextField("");
		JButton bSelect = new JButton("查找");
		tfsno.setPreferredSize(new Dimension(120, 30));
		JButton a5 = new JButton("返回");
		p.add(a5);
		a5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		p.add(lsno);
		p.add(tfsno);
		p.add(bSelect);
		bSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String sno = tfsno.getText();
				if (sno.length() == 0) {
					JOptionPane.showMessageDialog(f, "输入错误！");
					tfsno.grabFocus();
				} else {
					staffInfoInterface dao = new staffInfoInterface();
					staffInfo h = new staffInfo();
					h.sno = sno;
					String a = dao.seek(h.sno);
					int b = Integer.valueOf(a);
					t.getSelectionModel().setSelectionInterval(b-1, b-1);
					htm.staffs = dao.list();
					t.updateUI();
				}
			}
		});
		JScrollPane sp = new JScrollPane(t);
		f.add(p, "North");
		f.add(sp, "Center");
		f.setDefaultCloseOperation(3);
		f.setVisible(true);
	}
}
