package staffTable;

import data.staffInfo;
import data.staffInfoInterface;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class delete {
	
	public void deleteFunction(){
		final JFrame f = new JFrame("删除员工信息");
		f.setSize(400, 300);
		f.setLocation(200, 200);
		f.setLayout(new BorderLayout());
		final model htm = new model();
		final JTable t = new JTable(htm);
		JPanel p = new JPanel();
		JLabel lnumber = new JLabel("编号");
		final JTextField tfnumber = new JTextField("");
		tfnumber.setText("");
		JButton bAdd = new JButton("删除");
		tfnumber.setPreferredSize(new Dimension(120, 30));
		JButton a5 = new JButton("返回");
		p.add(a5);
		a5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		p.add(lnumber);
		p.add(tfnumber);
		p.add(bAdd);
		bAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = tfnumber.getText();
				if (name.length() == 0) {
					JOptionPane.showMessageDialog(f, "输入错误！");
					tfnumber.grabFocus();
				} else {
					staffInfoInterface dao = new staffInfoInterface();
					staffInfo h = new staffInfo();
					h.sno = tfnumber.getText();
					dao.delete(h.sno);
					htm.staffs = dao.list();
					t.updateUI();
				}
			}
		});
		JScrollPane sp = new JScrollPane(t);
		f.add(p, "North");
		f.add(sp, "Center");
		f.setDefaultCloseOperation(3);
		f.setVisible(true);
	}
	
}
