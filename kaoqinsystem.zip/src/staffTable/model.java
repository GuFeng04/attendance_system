package staffTable;

import data.staffInfo;
import data.staffInfoInterface;

import java.util.List;
import javax.swing.table.AbstractTableModel;

public class model extends AbstractTableModel{
	String[] columnNames = new String[]{"编号", "姓名", "年龄", "职位", "性别"};
	public List<staffInfo> staffs = (new staffInfoInterface()).list();
	
	public model() {
	}
	
	public int getRowCount() {
		return this.staffs.size();
	}
	
	public int getColumnCount() {
		return this.columnNames.length;
	}
	
	public String getColumnName(int columnIndex) {
		return this.columnNames[columnIndex];
	}
	
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}
	
	public Object getValueAt(int rowIndex, int columnIndex) {
		staffInfo h = (staffInfo)this.staffs.get(rowIndex);
		if (columnIndex == 0) {
			return h.sno;
		} else if (1 == columnIndex) {
			return h.sname;
		} else if (2 == columnIndex) {
			return h.sage;
		} else if (3 == columnIndex) {
			return h.spos;
		} else {
			return 4 == columnIndex ? h.ssex : null;
		}
	}
}
