package window;

import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class adminInterface {
	public adminInterface(){
	}
	
	public static void main(String[] args) {
	}
	
	//管理员登录后，呈现的界面，实现简单的增删改查
	public void layout(){
		final JFrame f = new JFrame("考勤管理系统");
		f.setSize(900, 540);//定义窗口大小，适应图片
		f.setLocation(300, 300);
		f.setLayout((LayoutManager)null);
		
		JLabel lBackground = new JLabel();
		ImageIcon img = new ImageIcon("src/img/loginImg.png");
		lBackground.setIcon(img);
		lBackground.setBounds(0,40,img.getIconWidth(),img.getIconHeight());
		
		//选项
		JButton staff     = new JButton("员工信息");
		JButton work      = new JButton("出勤记录");
		JButton overwork  = new JButton("加班记录");
		JButton offwork   = new JButton("请假记录");
		JButton outwork   = new JButton("出差记录");
		JButton monthwork = new JButton("月统计");
		
		//布局
		staff.setBounds(0, 1, 140, 30);
		work.setBounds(141, 1, 140, 30);
		overwork.setBounds(282, 1, 140, 30);
		offwork.setBounds(423, 1, 140, 30);
		outwork.setBounds(564, 1, 140, 30);
		monthwork.setBounds(705, 1, 100, 30);
		
		//跳转到对应的表，但是只做了staff的增删改查，由于每一个表都需要创造一个新的链表，为了节约工作量，同理可得。
		staff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				staff staff1 = new staff();
				f.dispose();
				staff1.layout();
			}
		});
		work.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				work work1 = new work();
				f.dispose();
				work1.layout();
			}
		});
		overwork.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				overwork overwork1 = new overwork();
				f.dispose();
				overwork1.layout();
			}
		});
		offwork.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				offwork offwork1 = new offwork();
				f.dispose();
				offwork1.layout();
			}
		});
		outwork.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				outwork outwork1 = new outwork();
				f.dispose();
				outwork1.layout();
			}
		});
		monthwork.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				monthwork monthwork1 = new monthwork();
				f.dispose();
				monthwork1.layout();
			}
		});
		
		
		f.add(lBackground);
		f.add(staff);
		f.add(work);
		f.add(overwork);
		f.add(offwork);
		f.add(outwork);
		f.add(monthwork);
		f.setDefaultCloseOperation(3);//隐藏并释放窗体
		f.setVisible(true);
	}
}
