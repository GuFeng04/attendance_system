package window;

public class main {
	public main() {
	}
	
	public static void main(String[] args) {
		//初始化对象
		login a = new login();
		//生成主窗口
		a.login2();
	}
}
