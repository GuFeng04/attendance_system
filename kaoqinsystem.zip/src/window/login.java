package window;

import java.awt.Dimension;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class login {
	public login(){
	
	}
	public void  login2(){
		//初始化JFrame对象，设置大小和初始位置
		final JFrame f = new JFrame("登录");
		//匹配图片width377
		f.setSize(377,330);
		f.setLocation(300,300);
		f.setLayout((LayoutManager) null);
		//登录
		JPanel pNorth = new JPanel();
		pNorth.setBounds(10,150,300,100);
		
		//账号标签和文本框
		JLabel lName = new JLabel("账号：");
		lName.setBounds(10,10,10,10);
		final JTextField tfName = new JTextField("");
		tfName.setText("");
		tfName.setPreferredSize(new Dimension(80,30));
		//密码及其文本框
		JLabel lPassword = new JLabel("密码");
		final JPasswordField tfPassword = new JPasswordField("");
		tfPassword.setText("");
		tfPassword.setPreferredSize(new Dimension(80,30));
		
		pNorth.add(lName);
		pNorth.add(tfName);
		pNorth.add(lPassword);
		pNorth.add(tfPassword);
		
		//设置一个背景图片
		JLabel lBackground = new JLabel();
		ImageIcon img = new ImageIcon("src/img/loginImgMini.png");
		lBackground.setIcon(img);
		//设置大小和位置
		lBackground.setBounds(0,1,img.getIconWidth(),img.getIconHeight());
		lBackground.setVisible(true);
		f.add(lBackground);
		
		/**
		 * 选择是管理员登录还是员工登录，管理员登录中可以使用增删改查，而员工登录只能使用查
		 */
		JButton loginWirhAdmin = new JButton("管理员登录");
		loginWirhAdmin.setBounds(130,200,100,30);
		f.add(loginWirhAdmin);
		JButton loginWithUser = new JButton("员工登录");
		loginWithUser.setBounds(130,240,100,30);
		f.add(loginWithUser);
		
		//监听器，监听Admin按钮，判断是否正确登录
		loginWirhAdmin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String name = tfName.getText();
				String password = new String(tfPassword.getPassword());
				if(name.length() == 0){
					JOptionPane.showMessageDialog(f,"账号不能为空");
				}else if(password.length() == 0){
					JOptionPane.showMessageDialog(f,"密码不能为空");
				}else{
					if(login.check(name,password)){
						//check（）账号密码是否正确，如果正确，那么登录
						//登录后进入管理员界面
						JOptionPane.showMessageDialog(f,"登录成功");
						adminInterface adminIF = new adminInterface();
						//关闭窗口，释放资源
						f.dispose();
						//调用管理员应该看见的界面
						adminIF.layout();
					}else{
						JOptionPane.showMessageDialog(f,"ERROR");
					}
				}
			}
		});
		
		//员工登录
		loginWithUser.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String name = tfName.getText();
				String password = new String(tfPassword.getPassword());
				if (name.length() == 0) {
					JOptionPane.showMessageDialog(f, "账号不能为空");
					tfName.grabFocus();
				} else if (password.length() == 0) {
					JOptionPane.showMessageDialog(f, "密码不能为空");
					tfPassword.grabFocus();
				} else {
					if (login.userCheck(name, password)) {
						JOptionPane.showMessageDialog(f, "登陆成功");
						f.dispose();
						userInterface userIF = new userInterface();
						userIF.layout();
					} else {
						JOptionPane.showMessageDialog(f, "ERROR!");
					}

				}
			}
		});
		f.add(pNorth);
		f.setDefaultCloseOperation(3);//隐藏并释放窗体
		f.setVisible(true);
	}

	public static boolean check(String user,String password){
		String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url = "jdbc:sqlserver://localhost;database=kaoqin";
		
		boolean result = false;
		Connection conn = null;
		Statement stmt = null;
		//注册驱动
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try{
			//获取连接
			conn=DriverManager.getConnection(url,"kaoqin","123456");
			//获取数据库操作对象
			stmt = conn.createStatement();
			//在loginInfo里面写死了两个账号和密码

			String sql = "select * from adminInfo where username= '" + user + "' and userpassword = '" + password + "'";
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()) {
				result = true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			//释放资源
			if(stmt != null){
				try{
					stmt.close();
				}catch (SQLException e){
					e.printStackTrace();
				}
			}
			if(conn != null){
				try{
					conn.close();
				}catch (SQLException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public static  boolean userCheck(String user,String password){
		String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url = "jdbc:sqlserver://localhost;database=kaoqin";
		
		boolean result = false;
		Connection conn = null;
		Statement stmt = null;
		//注册驱动
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try{
			//获取连接
			conn=DriverManager.getConnection(url,"kaoqin","123456");
			//获取数据库操作对象
			stmt = conn.createStatement();
			//执行sql语句
			String sql = "select * from loginInfo where username= '" + user + "' and userpassword = '" + password + "'";
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()) {
				result = true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			//释放资源
			if(stmt != null){
				try{
					stmt.close();
				}catch (SQLException e){
					e.printStackTrace();
				}
			}
			if(conn != null){
				try{
					conn.close();
				}catch (SQLException e){
					e.printStackTrace();
				}
			}
		}
		
		return result;
	}
	
	public static void main(String[] args){
	}
	
	
}
