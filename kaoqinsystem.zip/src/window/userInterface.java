package window;

import staffTable.userSelect;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class userInterface {
	public userInterface(){
	
	}
	
	public static void main(String[] args) {
	
	}
	public void layout(){
		final JFrame f = new JFrame("考勤管理系统");
		f.setSize(900, 540);
		f.setLocation(300, 300);
		f.setLayout((LayoutManager)null);
		
		JLabel lBackground = new JLabel();
		ImageIcon img = new ImageIcon("src/img/loginImg.png");
		lBackground.setIcon(img);
		lBackground.setBounds(0,40,img.getIconWidth(),img.getIconHeight());
		
		JButton selectButton = new JButton("查看员工信息");
		JButton exitButton   = new JButton("退出系统");
		selectButton.setBounds(111, 1, 140, 30);
		exitButton.setBounds(333, 1, 140, 30);
		
		selectButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				userSelect add2 = new userSelect();
				add2.selectFunction();
			}
		});
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		
		f.add(lBackground);
		f.add(selectButton);
		f.add(exitButton);
		f.setDefaultCloseOperation(3);
		f.setVisible(true);
	}
}
