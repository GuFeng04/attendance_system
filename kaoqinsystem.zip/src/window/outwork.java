package window;

public class outwork {
	public outwork() {
	}
	
	public static void main(String[] args) {
	}
	
	
	public void layout() {
	}
}
