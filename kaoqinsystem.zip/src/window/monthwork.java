package window;

public class monthwork {
	public monthwork() {
	}
	
	public static void main(String[] args) {
	}
	
	
	public void layout() {
	}
}
