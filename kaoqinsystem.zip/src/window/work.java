package window;

import staffTable.add;
import staffTable.delete;
import staffTable.select;
import staffTable.update;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class work {
	public work(){
	}
	
	public static void main(String[] args) {
	}
	
	//管理员登录后，呈现的界面，实现简单的增删改查
	public void layout(){
		final JFrame f = new JFrame("考勤管理系统");
		f.setSize(900, 540);
		f.setLocation(300, 300);
		f.setLayout((LayoutManager)null);
		
		JLabel lBackground = new JLabel();
		ImageIcon img = new ImageIcon("src/img/loginImg.png");
		lBackground.setIcon(img);
		lBackground.setBounds(0,40,img.getIconWidth(),img.getIconHeight());
		
		//选项
		JButton addButton    = new JButton("员工信息");
		JButton deleteButton = new JButton("出勤记录");
		JButton selectButton = new JButton("加班记录");
		JButton updateButton = new JButton("请假记录");
		JButton exitButton   = new JButton("出差记录");
		
		addButton.setBounds(0, 1, 140, 30);
		deleteButton.setBounds(141, 1, 140, 30);
		selectButton.setBounds(282, 1, 140, 30);
		updateButton.setBounds(423, 1, 140, 30);
		exitButton.setBounds(664, 1, 100, 30);
		
		//监听器
		addButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				add add1 = new add();
				add1.addFunction();
			}
		});
		deleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				delete add1 = new delete();
				add1.deleteFunction();
			}
		});
		selectButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				select add2 = new select();
				add2.selectFunction();
			}
		});
		updateButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				update add2 = new update();
				add2.updateFunction();
			}
		});
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		
		f.add(lBackground);
		f.add(addButton);
		f.add(deleteButton);
		f.add(selectButton);
		f.add(updateButton);
		f.add(exitButton);
		f.setDefaultCloseOperation(3);
		f.setVisible(true);
	}
}
