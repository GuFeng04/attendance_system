package window;

public class overwork {
	public overwork() {
	}
	
	public static void main(String[] args) {
	}
	
	
	public void layout() {
	}
}