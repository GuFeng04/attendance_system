package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class staffInfoInterface implements staffInterface{
	public staffInfoInterface(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public Connection getConnection() throws SQLException {
		return DriverManager.getConnection("jdbc:sqlserver://localhost;database=kaoqin","kaoqin","123456");
	}
	public int getTotal(){
		int total = 0;
		
		Connection conn = null;
		Statement stmt = null;
		try{
			//获取连接
			conn=this.getConnection();
			//获取数据库操作对象
			stmt = conn.createStatement();
			//执行sql语句
			String sql = "select count(*) from staff";
			ResultSet rs = stmt.executeQuery(sql);
			while(true) {
				if (!rs.next()) {
					System.out.println("total:" + total);
					break;
				}
				total = rs.getInt(1);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			//释放资源
			if(stmt != null){
				try{
					stmt.close();
				}catch (SQLException e){
					e.printStackTrace();
				}
			}
			if(conn != null){
				try{
					conn.close();
				}catch (SQLException e){
					e.printStackTrace();
				}
			}
		}
		return total;
	}
	

	public void add(staffInfo staff1) {
		String sql = "insert into staff values(?,?,?,?,?)";
		
		Connection conn = null;
		PreparedStatement ps = null;
		try{
			//获取连接
			conn=getConnection();
			//获取数据库操作对象
			ps = conn.prepareStatement(sql);
			//执行sql语句
			//将值传进staffInfo表中
			ps.setString(1, staff1.sno);
			ps.setString(2, staff1.sname);
			ps.setInt(3, staff1.sage);
			ps.setString(4, staff1.spos);
			ps.setString(5, staff1.ssex);
			ps.execute();
			ResultSet rs = ps.getGeneratedKeys();
			if (rs.next()) {
				String sno = rs.getString(1);
				staff1.sno = sno;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			//释放资源
			if(ps != null){
				try{
					ps.close();
				}catch (SQLException e){
					e.printStackTrace();
				}
			}
			if(conn != null){
				try{
					conn.close();
				}catch (SQLException e){
					e.printStackTrace();
				}
			}
		}
	}
	
	public void add2(String m, int n) {
		String sql = "insert into loginInfo values(?,?)";
		
		Throwable var4 = null;
		Object var5 = null;
		
		try {
			Connection c = this.getConnection();
			
			try {
				PreparedStatement ps = c.prepareStatement(sql);
				
				try {
					ps.setString(1, m);
					ps.setInt(2, n);
					ResultSet rs = ps.getGeneratedKeys();
					if (rs.next()) {
						int number = rs.getInt(1);
					}
				} finally {
					if (ps != null) {
						ps.close();
					}
					
				}
			} catch (Throwable var23) {
				if (var4 == null) {
					var4 = var23;
				} else if (var4 != var23) {
					var4.addSuppressed(var23);
				}
				
				if (c != null) {
					c.close();
				}
				
				throw var4;
			}
			
			if (c != null) {
				c.close();
			}
		} catch (Throwable var24) {
			if (var4 == null) {
				var4 = var24;
			} else if (var4 != var24) {
				var4.addSuppressed(var24);
			}
			
			try {
				throw var4;
			} catch (Throwable throwable) {
				throwable.printStackTrace();
			}
		}
	}
	
	public void update(staffInfo staff1) {
		String sql = "update staff set  sname = ? , sage = ? , spos = ?, ssex = ? where sno = ?";
		
		Throwable var3 = null;
		Object var4 = null;
		
		try {
			Connection c = this.getConnection();
			
			try {
				PreparedStatement ps = c.prepareStatement(sql);
				
				try {
					ps.setString(1, staff1.sname);
					ps.setInt(2, staff1.sage);
					ps.setString(3, staff1.spos);
					ps.setString(4, staff1.ssex);
					ps.setString(5, staff1.sno);
					ps.execute();
				} finally {
					if (ps != null) {
						ps.close();
					}
					
				}
			} catch (Throwable var20) {
				if (var3 == null) {
					var3 = var20;
				} else if (var3 != var20) {
					var3.addSuppressed(var20);
				}
				
				if (c != null) {
					c.close();
				}
				
				throw var3;
			}
			
			if (c != null) {
				c.close();
			}
		} catch (Throwable var21) {
			if (var3 == null) {
				var3 = var21;
			} else if (var3 != var21) {
				var3.addSuppressed(var21);
			}
			
			try {
				throw var3;
			} catch (Throwable throwable) {
				throwable.printStackTrace();
			}
		}
		
	}
	
	public void delete(String sno) {
		Throwable var2 = null;
		Object var3 = null;
		
		try {
			Connection c = this.getConnection();
			
			try {
				Statement s = c.createStatement();
				
				try {
					String sql = "delete from staff where sno = " + sno;
					s.execute(sql);
				} finally {
					if (s != null) {
						s.close();
					}
					
				}
			} catch (Throwable var20) {
				if (var2 == null) {
					var2 = var20;
				} else if (var2 != var20) {
					var2.addSuppressed(var20);
				}
				
				if (c != null) {
					c.close();
				}
				
				throw var2;
			}
			
			if (c != null) {
				c.close();
			}
		} catch (Throwable var21) {
			if (var2 == null) {
				var2 = var21;
			} else if (var2 != var21) {
				var2.addSuppressed(var21);
			}
			
			try {
				throw var2;
			} catch (Throwable throwable) {
				throwable.printStackTrace();
			}
		}
		
	}
	public staffInfo get(String sno) {
		staffInfo staff1 = null;
		
		Throwable var3 = null;
		Object var4 = null;
		
		try {
			Connection c = this.getConnection();
			
			try {
				Statement s = c.createStatement();
				
				try {
					String sql = "select * from staff where number = " + sno;
					ResultSet rs = s.executeQuery(sql);
					if (rs.next()) {
						staff1 = new staffInfo();
						sno = rs.getString("sno");
						String sname = rs.getString("sname");
						int sage = rs.getInt("sage");
						String spos = rs.getString("spos");
						String ssex = rs.getString("ssex");
						staff1.sno = sno;
						staff1.sname = sname;
						staff1.sage = sage;
						staff1.spos = spos;
						staff1.ssex = ssex;
					}
				} finally {
					if (s != null) {
						s.close();
					}
					
				}
			} catch (Throwable var27) {
				if (var3 == null) {
					var3 = var27;
				} else if (var3 != var27) {
					var3.addSuppressed(var27);
				}
				
				if (c != null) {
					c.close();
				}
				
				throw var3;
			}
			
			if (c != null) {
				c.close();
			}
		} catch (Throwable var28) {
			if (var3 == null) {
				var3 = var28;
			} else if (var3 != var28) {
				var3.addSuppressed(var28);
			}
			
			try {
				throw var3;
			} catch (Throwable throwable) {
				throwable.printStackTrace();
			}
		}
		
		return staff1;
	}
	
	public String seek(String sno) {
		staffInfo staff1 = null;
		
		Throwable var3 = null;
		Object var4 = null;
		
		try {
			Connection c = this.getConnection();
			
			try {
				Statement s = c.createStatement();
				
				try {
					String sql = "select * from (select *,row_number() over (order by [sno]) 'x' from staff) as asd where sno=" + sno;
					ResultSet rs = s.executeQuery(sql);
					if (rs.next()) {
						staff1 = new staffInfo();
						String sno1 = rs.getString("x");
						staff1.sno = sno1;
					}
				} finally {
					if (s != null) {
						s.close();
					}
					
				}
			} catch (Throwable var23) {
				if (var3 == null) {
					var3 = var23;
				} else if (var3 != var23) {
					var3.addSuppressed(var23);
				}
				
				if (c != null) {
					c.close();
				}
				
				throw var3;
			}
			
			if (c != null) {
				c.close();
			}
		} catch (Throwable var24) {
			if (var3 == null) {
				var3 = var24;
			} else if (var3 != var24) {
				var3.addSuppressed(var24);
			}
			
			try {
				throw var3;
			} catch (Throwable throwable) {
				throwable.printStackTrace();
			}
		}
		
		return staff1.sno;
	}
	
	public String seek2(String sno) {
		staffInfo staff1 = null;
		
		Throwable var3 = null;
		Object var4 = null;
		
		try {
			Connection c = this.getConnection();
			
			try {
				Statement s = c.createStatement();
				
				try {
					String sql = "select * from staff where sno=" + sno;
					ResultSet rs = s.executeQuery(sql);
					if (rs.next()) {
						staff1 = new staffInfo();
						String sno1 = rs.getString("x");
						staff1.sno = sno1;
					}
				} finally {
					if (s != null) {
						s.close();
					}
					
				}
			} catch (Throwable var23) {
				if (var3 == null) {
					var3 = var23;
				} else if (var3 != var23) {
					var3.addSuppressed(var23);
				}
				
				if (c != null) {
					c.close();
				}
				
				throw var3;
			}
			
			if (c != null) {
				c.close();
			}
		} catch (Throwable var24) {
			if (var3 == null) {
				var3 = var24;
			} else if (var3 != var24) {
				var3.addSuppressed(var24);
			}
			
			try {
				throw var3;
			} catch (Throwable throwable) {
				throwable.printStackTrace();
			}
		}
		
		return staff1.sno;
	}
	public List<staffInfo> list() {
		return this.list(0, 32767);
	}
	
	public List<staffInfo> list(int start, int count) {
		List<staffInfo> staffs = new ArrayList();
		String sql = "SELECT * FROM staff order by sno  offset ? rows fetch next ? rows only ";
		
		Connection conn = null;
		PreparedStatement ps = null;
		Throwable var5 = null;
		Object var6 = null;
		
		try {
			Connection c = this.getConnection();
			try {
				 ps = c.prepareStatement(sql);
				try {
					ps.setInt(1, start);
					ps.setInt(2, count);
					ResultSet rs = ps.executeQuery();
					while(rs.next()) {
						staffInfo staff1 = new staffInfo();
						String sno = rs.getString("sno");
						String sname = rs.getString("sname");
						int sage = rs.getInt("sage");
						String spos = rs.getString("spos");
						String ssex = rs.getString("ssex");
						staff1.sno = sno;
						staff1.sname = sname;
						staff1.sage = sage;
						staff1.spos = spos;
						staff1.ssex = ssex;
						staffs.add(staff1);
					}
				} finally {
					if (ps != null) {
						ps.close();
					}
				}
			} catch (Throwable var30) {
				if (var5 == null) {
					var5 = var30;
				} else if (var5 != var30) {
					var5.addSuppressed(var30);
				}
				
				if (c != null) {
					c.close();
				}
				throw var5;
			}
			if (c != null) {
				c.close();
			}
		} catch (Throwable var31) {
			if (var5 == null) {
				var5 = var31;
			} else if (var5 != var31) {
				var5.addSuppressed(var31);
			}
			try {
				throw var5;
			} catch (Throwable throwable) {
				throwable.printStackTrace();
			}
		}
		return staffs;
	}
}
