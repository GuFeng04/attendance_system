package data;

public class staffInfo {
	//staff表
	public String sno;
	public String sname;
	public int sage;
	public String spos;
	public String ssex;
	
	public staffInfo(){
	
	}
}
