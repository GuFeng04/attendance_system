package data;

import java.util.List;

public interface staffInterface {
	//staff接口
	void add(staffInfo var1);
	
	void update(staffInfo var1);
	
	void delete(String var1);
	
	staffInfo get(String var1);
	
	List<staffInfo> list();
	
	List<staffInfo> list(int var1, int var2);
}
